#pragma once
struct Pose6D {
    double x, y, z, rx, ry, rz;
};